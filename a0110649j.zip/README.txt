This is the README file for A0110649J's submission

== General Notes about this assignment ==

Main submission file: 
index.py : indexer, builds dic and postings
search.py^ : performs boolean search
== Files included with this submission ==

ESSAY.txt
	- txt file containing answers to the questions
README.txt
	- this file
	
== Statement of individual work ==

Please initial one of the following statements.

[X] I, A0110649J, certify that I have followed the CS 3245 Information
Retrieval class guidelines for homework assignments.  In particular, I
expressly vow that I have followed the Facebook rule in discussing
with others in doing the assignment and did not take notes (digital or
printed) from the discussions.  

== References ==
Once again, since this is my first python course, many methods and their usage were found on stackoverflow and docs.python.org.
Architecture and experiments were designed based on lecture notes
Adapted RPN from mathematical operations to boolean, also on stack overflow
email address: A0110649J@u.nus.edu
